import sys
import os
import json
import shutil
import hashlib
from datetime import datetime, timedelta
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QListWidget, QFileDialog, QMessageBox, QInputDialog
)
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QIcon

USUARIOS_FILE = 'usuarios.json'
ENVIO_FILE = 'envios.json'  # Registro de archivos enviados
BASE_CARPETA = os.path.abspath('Poligonos Compartidos')
ADMIN_CARPETA = os.path.abspath('AdminFiles')
EXTENSIONES_PERMITIDAS = {'shp', 'kml', 'kmz', 'job', 'prj', 'dsp', 'no1'}

ADMIN_USER = 'AnanGomez'
ADMIN_PASS = 'Sami1203'

def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def cargar_usuarios():
    if not os.path.exists(USUARIOS_FILE):
        return {}
    try:
        with open(USUARIOS_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        with open(USUARIOS_FILE, 'w') as f:
            f.write('{}')
        return {}

def guardar_usuarios(usuarios):
    with open(USUARIOS_FILE, 'w') as f:
        json.dump(usuarios, f)

def cargar_envios():
    if not os.path.exists(ENVIO_FILE):
        return {}
    try:
        with open(ENVIO_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        with open(ENVIO_FILE, 'w') as f:
            f.write('{}')
        return {}

def guardar_envios(envios):
    with open(ENVIO_FILE, 'w') as f:
        json.dump(envios, f, indent=2)

def verificar_usuario(username, password):
    usuarios = cargar_usuarios()
    password_hash = hash_password(password)
    return usuarios.get(username) == password_hash

def agregar_usuario(username, password):
    usuarios = cargar_usuarios()
    if username in usuarios:
        return False
    usuarios[username] = hash_password(password)
    guardar_usuarios(usuarios)
    # Crear carpeta correspondiente
    if username == ADMIN_USER:
        os.makedirs(ADMIN_CARPETA, exist_ok=True)
    else:
        os.makedirs(os.path.join(BASE_CARPETA, username), exist_ok=True)
    return True

def eliminar_usuario(username):
    usuarios = cargar_usuarios()
    if username in usuarios and username != ADMIN_USER:
        del usuarios[username]
        guardar_usuarios(usuarios)
        shutil.rmtree(os.path.join(BASE_CARPETA, username), ignore_errors=True)
        return True
    return False

def cambiar_contrasena(username, nueva_password):
    usuarios = cargar_usuarios()
    if username in usuarios:
        usuarios[username] = hash_password(nueva_password)
        guardar_usuarios(usuarios)
        return True
    return False

def extension_valida(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in EXTENSIONES_PERMITIDAS

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Login')
        self.setWindowIcon(QIcon('geoshare.ico'))
        self.resize(300, 120)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.user_input = QLineEdit()
        self.pass_input = QLineEdit()
        self.pass_input.setEchoMode(QLineEdit.Password)
        login_btn = QPushButton('Entrar')
        login_btn.clicked.connect(self.check_login)

        layout.addWidget(QLabel('Usuario:'))
        layout.addWidget(self.user_input)
        layout.addWidget(QLabel('Contraseña:'))
        layout.addWidget(self.pass_input)
        layout.addWidget(login_btn)
        self.setLayout(layout)

    def check_login(self):
        user = self.user_input.text()
        passwd = self.pass_input.text()
        if verificar_usuario(user, passwd):
            self.accepted(user)
        else:
            QMessageBox.warning(self, 'Error', 'Usuario o contraseña incorrectos')

    def accepted(self, user):
        self.main_window = MainWindow(user)
        self.main_window.show()
        self.close()

class MainWindow(QWidget):
    def __init__(self, usuario):
        super().__init__()
        self.usuario = usuario
        self.archivos_recibidos_anteriores = set()
        self.setWindowTitle(f'GeoShare - Usuario: {usuario}')
        self.setWindowIcon(QIcon('geoshare.ico'))
        self.resize(800, 500)
        self.init_ui()
        self.cargar_listas()

        # Timer para revisión periódica de archivos recibidos
        self.timer = QTimer()
        self.timer.timeout.connect(self.chequear_nuevos_archivos)
        self.timer.start(5000)  # Cada 5 segundos

        # Timer para heartbeat (actualizar archivo .online)
        self.timer_heartbeat = QTimer()
        self.timer_heartbeat.timeout.connect(self.actualizar_heartbeat)
        self.timer_heartbeat.start(30000)  # Cada 30 segundos
        self.actualizar_heartbeat()  # Ejecutar una vez al iniciar

        # Timer para actualizar usuarios en línea
        self.timer_check_online = QTimer()
        self.timer_check_online.timeout.connect(self.chequear_usuarios_en_linea)
        self.timer_check_online.start(30000)  # Cada 30 segundos
        self.chequear_usuarios_en_linea()

    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.addWidget(QLabel(f'Bienvenido {self.usuario}'))

        layout = QHBoxLayout()

        # Panel Archivos Recibidos
        vbox_recibidos = QVBoxLayout()
        vbox_recibidos.addWidget(QLabel("Archivos Recibidos"))
        self.lista_recibidos = QListWidget()
        vbox_recibidos.addWidget(self.lista_recibidos)

        # Panel Archivos Enviados
        vbox_enviados = QVBoxLayout()
        vbox_enviados.addWidget(QLabel("Archivos Enviados"))
        self.lista_enviados = QListWidget()
        vbox_enviados.addWidget(self.lista_enviados)

        layout.addLayout(vbox_recibidos)
        layout.addLayout(vbox_enviados)

        main_layout.addLayout(layout)

        # Lista usuarios en línea
        main_layout.addWidget(QLabel("Usuarios en línea"))
        self.lista_usuarios_linea = QListWidget()
        main_layout.addWidget(self.lista_usuarios_linea)

        # Botones
        btns = QHBoxLayout()

        btn_subir = QPushButton('Subir archivo')
        btn_subir.clicked.connect(self.subir_archivo)
        btns.addWidget(btn_subir)

        btn_descargar_recibidos = QPushButton('Descargar archivo recibido')
        btn_descargar_recibidos.clicked.connect(self.descargar_archivo_recibido)
        btns.addWidget(btn_descargar_recibidos)

        btn_descargar_enviados = QPushButton('Descargar archivo enviado')
        btn_descargar_enviados.clicked.connect(self.descargar_archivo_enviado)
        btns.addWidget(btn_descargar_enviados)

        btn_cambiar_pass = QPushButton('Cambiar contraseña')
        btn_cambiar_pass.clicked.connect(self.cambiar_password)
        btns.addWidget(btn_cambiar_pass)

        btn_cerrar_sesion = QPushButton('Cerrar sesión')
        btn_cerrar_sesion.clicked.connect(self.cerrar_sesion)
        btns.addWidget(btn_cerrar_sesion)

        if self.usuario == ADMIN_USER:
            btn_gestionar_usuarios = QPushButton('Gestionar usuarios')
            btn_gestionar_usuarios.clicked.connect(self.gestionar_usuarios)
            btns.addWidget(btn_gestionar_usuarios)

            btn_eliminar_archivo = QPushButton('Eliminar archivo')
            btn_eliminar_archivo.clicked.connect(self.eliminar_archivo)
            btns.addWidget(btn_eliminar_archivo)

            btn_eliminar_registro = QPushButton('Eliminar registro enviado')
            btn_eliminar_registro.clicked.connect(self.eliminar_registro_envio)
            btns.addWidget(btn_eliminar_registro)

        main_layout.addLayout(btns)
        self.setLayout(main_layout)

    def actualizar_heartbeat(self):
        ruta_heartbeat = os.path.join(BASE_CARPETA, f"{self.usuario}.online")
        try:
            with open(ruta_heartbeat, 'w') as f:
                f.write(datetime.now().isoformat())
        except Exception as e:
            print(f"Error al actualizar heartbeat: {e}")

    def chequear_usuarios_en_linea(self):
        ahora = datetime.now()
        usuarios_online = []
        try:
            for archivo in os.listdir(BASE_CARPETA):
                if archivo.endswith('.online'):
                    ruta = os.path.join(BASE_CARPETA, archivo)
                    with open(ruta, 'r') as f:
                        timestamp_str = f.read().strip()
                    timestamp = datetime.fromisoformat(timestamp_str)
                    if ahora - timestamp < timedelta(minutes=2):
                        usuario_online = archivo[:-7]  # Quitar ".online"
                        usuarios_online.append(usuario_online)
        except Exception as e:
            print(f"Error al chequear usuarios en línea: {e}")

        self.lista_usuarios_linea.clear()
        self.lista_usuarios_linea.addItems(usuarios_online)

    def cargar_listas(self):
        self.cargar_archivos_recibidos()
        self.cargar_archivos_enviados()

    def cargar_archivos_recibidos(self):
        self.lista_recibidos.clear()

        if not os.path.exists(BASE_CARPETA):
            os.makedirs(BASE_CARPETA)
        if not os.path.exists(ADMIN_CARPETA):
            os.makedirs(ADMIN_CARPETA)

        if self.usuario == ADMIN_USER:
            archivos = [f for f in os.listdir(ADMIN_CARPETA) if extension_valida(f)]
            for archivo in archivos:
                self.lista_recibidos.addItem(f"{ADMIN_USER}/{archivo}")
            self.archivos_recibidos_anteriores = set(archivos)
        else:
            user_dir = os.path.join(BASE_CARPETA, self.usuario)
            if os.path.isdir(user_dir):
                archivos = [f for f in os.listdir(user_dir) if extension_valida(f)]
                for archivo in archivos:
                    self.lista_recibidos.addItem(archivo)
                self.archivos_recibidos_anteriores = set(archivos)
            else:
                self.archivos_recibidos_anteriores = set()

    def cargar_archivos_enviados(self):
        self.lista_enviados.clear()
        envios = cargar_envios()
        enviados = envios.get(self.usuario, [])
        for envio in enviados:
            fecha = envio.get('fecha', 'fecha desconocida')
            archivo = envio.get('archivo', '')
            destino = envio.get('destino', '')
            self.lista_enviados.addItem(f"{archivo} -> {destino} ({fecha})")

    def subir_archivo(self):
        archivo_path, _ = QFileDialog.getOpenFileName(
            self, 'Seleccionar archivo para subir', '',
            "Archivos permitidos (*.shp *.kml *.kmz *.job *.prj *.dsp *.no1)"
        )
        if not archivo_path:
            return
        usuarios = cargar_usuarios()
        usuarios.pop(self.usuario, None)
        if not usuarios:
            QMessageBox.information(self, 'Aviso', 'No hay usuarios disponibles para compartir.')
            return
        usuario_destino, ok = QInputDialog.getItem(self, 'Compartir archivo', 'Selecciona el usuario destino:',
                                                   list(usuarios.keys()), 0, False)
        if ok:
            if usuario_destino == ADMIN_USER:
                destino_dir = ADMIN_CARPETA
            else:
                destino_dir = os.path.join(BASE_CARPETA, usuario_destino)
            os.makedirs(destino_dir, exist_ok=True)
            nombre_archivo = os.path.basename(archivo_path)
            shutil.copy2(archivo_path, os.path.join(destino_dir, nombre_archivo))
            # Guardar registro de envío
            envios = cargar_envios()
            if self.usuario not in envios:
                envios[self.usuario] = []
            envios[self.usuario].append({
                'archivo': nombre_archivo,
                'destino': usuario_destino,
                'fecha': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            guardar_envios(envios)

            QMessageBox.information(self, 'Éxito', f'Archivo compartido con {usuario_destino}')
            self.cargar_listas()

    def descargar_archivo_recibido(self):
        item = self.lista_recibidos.currentItem()
        if not item:
            QMessageBox.warning(self, 'Error', 'Seleccione un archivo recibido.')
            return
        archivo = item.text()
        if self.usuario == ADMIN_USER:
            partes = archivo.split('/', 1)
            if len(partes) != 2:
                return
            user_folder, nombre_archivo = partes
            if user_folder == ADMIN_USER:
                origen = os.path.join(ADMIN_CARPETA, nombre_archivo)
            else:
                origen = os.path.join(BASE_CARPETA, user_folder, nombre_archivo)
        else:
            user_folder = self.usuario
            nombre_archivo = archivo
            origen = os.path.join(BASE_CARPETA, user_folder, nombre_archivo)

        destino_dir = QFileDialog.getExistingDirectory(self, 'Seleccionar carpeta destino')
        if destino_dir:
            shutil.copy2(origen, os.path.join(destino_dir, nombre_archivo))
            QMessageBox.information(self, 'Éxito', f'Archivo {nombre_archivo} guardado.')

    def descargar_archivo_enviado(self):
        item = self.lista_enviados.currentItem()
        if not item:
            QMessageBox.warning(self, 'Error', 'Seleccione un archivo enviado.')
            return
        texto = item.text()
        # Formato: "archivo.ext -> usuario (fecha)"
        try:
            archivo = texto.split(' -> ')[0]
            destino = texto.split(' -> ')[1].split(' (')[0]
        except Exception:
            QMessageBox.warning(self, 'Error', 'Formato de archivo enviado inválido.')
            return

        if destino == ADMIN_USER:
            origen = os.path.join(ADMIN_CARPETA, archivo)
        else:
            origen = os.path.join(BASE_CARPETA, destino, archivo)

        if not os.path.exists(origen):
            QMessageBox.warning(self, 'Error', 'El archivo enviado ya no existe.')
            return

        destino_dir = QFileDialog.getExistingDirectory(self, 'Seleccionar carpeta destino')
        if destino_dir:
            shutil.copy2(origen, os.path.join(destino_dir, archivo))
            QMessageBox.information(self, 'Éxito', f'Archivo {archivo} guardado.')

    def cambiar_password(self):
        nueva, ok = QInputDialog.getText(self, 'Cambiar contraseña', 'Nueva contraseña:', QLineEdit.Password)
        if ok and nueva.strip():
            cambiar_contrasena(self.usuario, nueva.strip())
            QMessageBox.information(self, 'Éxito', 'Contraseña cambiada correctamente.')

    def gestionar_usuarios(self):
        opciones = ['Agregar usuario', 'Eliminar usuario']
        accion, ok = QInputDialog.getItem(self, 'Gestionar usuarios', 'Seleccione acción:', opciones, 0, False)
        if not ok:
            return

        if accion == 'Agregar usuario':
            nombre, ok = QInputDialog.getText(self, 'Nuevo usuario', 'Nombre de usuario:')
            if not ok or not nombre.strip():
                return
            contrasena, ok2 = QInputDialog.getText(self, 'Nuevo usuario', 'Contraseña:', QLineEdit.Password)
            if not ok2 or not contrasena.strip():
                return
            if agregar_usuario(nombre.strip(), contrasena.strip()):
                QMessageBox.information(self, 'Éxito', f'Usuario {nombre} creado.')
            else:
                QMessageBox.warning(self, 'Error', 'El usuario ya existe.')

        elif accion == 'Eliminar usuario':
            usuarios = cargar_usuarios()
            usuarios.pop(ADMIN_USER, None)
            if not usuarios:
                QMessageBox.information(self, 'Aviso', 'No hay usuarios para eliminar.')
                return
            usuario_a_eliminar, ok = QInputDialog.getItem(self, 'Eliminar usuario', 'Seleccione el usuario a eliminar:', list(usuarios.keys()), 0, False)
            if ok:
                if eliminar_usuario(usuario_a_eliminar):
                    QMessageBox.information(self, 'Éxito', f'Usuario {usuario_a_eliminar} eliminado.')
                else:
                    QMessageBox.warning(self, 'Error', 'No se pudo eliminar el usuario.')

    def cerrar_sesion(self):
        # Borrar archivo .online
        ruta_heartbeat = os.path.join(BASE_CARPETA, f"{self.usuario}.online")
        try:
            os.remove(ruta_heartbeat)
        except FileNotFoundError:
            pass
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

    def eliminar_archivo(self):
        # Solo admin puede eliminar archivos de ambas listas
        item = self.lista_recibidos.currentItem() or self.lista_enviados.currentItem()
        if not item:
            QMessageBox.warning(self, 'Error', 'Seleccione un archivo para eliminar.')
            return

        archivo = item.text()
        if item in self.lista_recibidos.selectedItems():
            # Archivos recibidos (formato posible: "AnanGomez/archivo.ext" o solo "archivo.ext")
            if self.usuario == ADMIN_USER:
                partes = archivo.split('/', 1)
                if len(partes) != 2:
                    QMessageBox.warning(self, 'Error', 'Archivo inválido para eliminar.')
                    return
                user_folder, nombre_archivo = partes
                if user_folder == ADMIN_USER:
                    ruta_archivo = os.path.join(ADMIN_CARPETA, nombre_archivo)
                else:
                    ruta_archivo = os.path.join(BASE_CARPETA, user_folder, nombre_archivo)
            else:
                ruta_archivo = os.path.join(BASE_CARPETA, self.usuario, archivo)
        else:
            # Archivos enviados (formato: archivo -> destino (fecha))
            try:
                archivo_nombre = archivo.split(' -> ')[0]
                destino = archivo.split(' -> ')[1].split(' (')[0]
            except Exception:
                QMessageBox.warning(self, 'Error', 'Formato inválido para eliminar.')
                return
            if destino == ADMIN_USER:
                ruta_archivo = os.path.join(ADMIN_CARPETA, archivo_nombre)
            else:
                ruta_archivo = os.path.join(BASE_CARPETA, destino, archivo_nombre)

        if os.path.exists(ruta_archivo):
            os.remove(ruta_archivo)
            QMessageBox.information(self, 'Éxito', f'Archivo {os.path.basename(ruta_archivo)} eliminado.')
            self.cargar_listas()
        else:
            QMessageBox.warning(self, 'Error', 'El archivo no existe.')

    def eliminar_registro_envio(self):
        envios = cargar_envios()
        if self.usuario not in envios or not envios[self.usuario]:
            QMessageBox.information(self, 'Aviso', 'No hay registros para eliminar.')
            return
        items = [f"{e['archivo']} -> {e['destino']} ({e['fecha']})" for e in envios[self.usuario]]
        item, ok = QInputDialog.getItem(self, 'Eliminar registro enviado', 'Seleccione registro:', items, 0, False)
        if ok:
            idx = items.index(item)
            envios[self.usuario].pop(idx)
            guardar_envios(envios)
            QMessageBox.information(self, 'Éxito', 'Registro eliminado.')
            self.cargar_listas()

    def chequear_nuevos_archivos(self):
        # Revisa si hay archivos nuevos en carpeta usuario (archivos recibidos)
        if self.usuario == ADMIN_USER:
            carpeta = ADMIN_CARPETA
        else:
            carpeta = os.path.join(BASE_CARPETA, self.usuario)
        if not os.path.isdir(carpeta):
            return
        archivos_actuales = set(f for f in os.listdir(carpeta) if extension_valida(f))
        nuevos = archivos_actuales - self.archivos_recibidos_anteriores
        if nuevos:
            for nuevo in nuevos:
                QMessageBox.information(self, 'Archivo recibido', f'Nuevo archivo recibido: {nuevo}')
            self.archivos_recibidos_anteriores = archivos_actuales
            self.cargar_archivos_recibidos()

    def closeEvent(self, event):
        ruta_heartbeat = os.path.join(BASE_CARPETA, f"{self.usuario}.online")
        try:
            os.remove(ruta_heartbeat)
        except FileNotFoundError:
            pass
        event.accept()


if __name__ == '__main__':
    # Crear carpeta base y admin si no existen
    os.makedirs(BASE_CARPETA, exist_ok=True)
    os.makedirs(ADMIN_CARPETA, exist_ok=True)

    # Crear archivo usuarios.json con admin si no existe
    usuarios = cargar_usuarios()
    if ADMIN_USER not in usuarios:
        agregar_usuario(ADMIN_USER, ADMIN_PASS)

    app = QApplication(sys.argv)
    login = LoginWindow()
    login.show()
    sys.exit(app.exec())
